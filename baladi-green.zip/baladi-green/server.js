const express = require("express");
const fs = require("fs");

const app = express();

app.use(express.json());

app.use(express.static("public"));


function readReports() {

    const data = fs.readFileSync("reports.json", "utf8");

    return JSON.parse(data);

}


function saveReports(reports) {

    fs.writeFileSync(
        "reports.json",
        JSON.stringify(reports, null, 2)
    );

}


app.post("/api/reports", (req, res) => {

    const report = req.body;

    const reports = readReports();

    reports.push(report);

    saveReports(reports);

    res.status(201).json({

        message: "Report received successfully"

    });

});


app.get("/api/reports", (req, res) => {

    const reports = readReports();

    res.json(reports);

});


app.listen(3000, () => {

    console.log(
        "Server is running on http://localhost:3000"
    );

});