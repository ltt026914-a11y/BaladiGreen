const themeBtn = document.querySelector("#theme-btn");
const body = document.body;




const reportForm = document.querySelector("#reportForm");
const successMessage = document.querySelector("#successMessage");
const errorMessage = document.querySelector("#errorMessage");


reportForm.addEventListener("submit", async function (event) {

    event.preventDefault();

    successMessage.style.display = "none";
    errorMessage.style.display = "none";


    const report = {

        reportType: document.querySelector("#reportType").value,

        city: document.querySelector("#city").value,

        district: document.querySelector("#district").value,

        location: document.querySelector("#location").value,

        description: document.querySelector("#description").value

    };


    try {

        const response = await fetch("/api/reports", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(report)

        });


        if (response.ok) {

            successMessage.style.display = "flex";

            reportForm.reset();

        } else {

            errorMessage.style.display = "block";

        }


    } catch (error) {

        errorMessage.style.display = "block";

    }

});