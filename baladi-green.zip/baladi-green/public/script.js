const themeBtn = document.querySelector("#theme-btn");
const body = document.body;





const infoData = {

    plastic: {

        text: "الاهتمام يبدأ بخطوات بسيطة: فصل البلاستيك عن باقي النفايات، واختيار المنتجات القابلة لإعادة التدوير، ودعم المبادرات البيئية المحلية. هذه الخطوات الصغيرة تصنع أثرًا كبيرًا عندما نلتزم بها معًا.<br><br><span class=\"location-note\">يمكنك إيجاد الحاويات الحمراء والصفراء المخصصة للنفايات البلاستيكية أمام المراكز التجارية والمتنزهات العامة</span>",

        img: "https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?w=800&auto=format&fit=crop"

    },


    paper: {

        text: "إعادة تدوير الورق تحمي الأشجار والغابات وتوفر كميات ضخمة من المياه والطاقة. تقليل استهلاك الورق وإعادة استخدامه يساهم بشكل مباشر في استدامة مواردنا الطبيعية.<br><br><span class=\"location-note\">يمكنك إيجاد الحاويات الزرقاء المخصصة للنفايات الورقية أمام المدارس والمكتبات والمباني الإدارية</span>",

        img: "https://images.unsplash.com/photo-1603484477859-abe6a73f9366?w=800&auto=format&fit=crop"

    },


    metals: {

        text: "المعادن مواد غالية الثمن وقابلة للتدوير بلا نهاية. تجميع العلب المعدنية والألمنيوم يقلل الانبعاثات الكربونية الناتجة عن عمليات التعدين الصعبة.<br><br><span class=\"location-note\">يمكنك إيجاد الحاويات الصفراء المخصصة للنفايات المعدنية أمام مراكز الاستلام المعتمدة داخل الأحياء</span>",

        img: "https://media.elwatannews.com/media/img/mediaarc/large/16652643671686733837.jpg"

    },


    glass: {

        text: "الزجاج مادة نقية وقابلة لإعادة التدوير بنسبة 100% دون خفض جودتها. فصل العبوات الزجاجية يحمي البيئة ويقلل من حجم النفايات الصلبة.<br><br><span class=\"location-note\">يمكنك إيجاد الحاويات الخضراء المخصصة للنفايات الزجاجية أمام الأسواق والمناطق السكنية</span>",

        img: "https://www.albayan.ae/assets/archives/images/2021/08/11/4225059.gif"

    },


    electronics: {

        text: "النفايات الإلكترونية تحتوي على معادن ثمينة ومواد قد تكون خطرة. التخلص الصحيح من الأجهزة القديمة يحمي التربة والمياه الجوفية من التلوث.<br><br><span class=\"location-note\">يمكنك إيجاد الحاويات السلمية والرمادية المخصصة للنفايات الإلكترونية أمام متاجر الأجهزة الكبرى ومراكز إعادة التدوير</span>",

        img: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop"

    }

};


const categoryBtns = document.querySelectorAll(".category .btn");

const infoBox = document.querySelector("#info-box");

const infoImg = document.querySelector("#info-img");

const infoText = document.querySelector("#info-text");


categoryBtns.forEach(function (btn) {

    btn.addEventListener("mouseenter", function () {

        const type = this.getAttribute("data-info");

        if (infoData[type]) {

            infoImg.src = infoData[type].img;

            infoText.innerHTML = infoData[type].text;

            infoBox.classList.remove("hidden");

        }

    });


    btn.addEventListener("mouseleave", function () {

        infoBox.classList.add("hidden");

    });

});